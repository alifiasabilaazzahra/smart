<?php

use Illuminate\Database\Seeder;
use Faker\Factory as Faker;

class StudentTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $jml_id=DB::table('student')->count();
        $id=$jml_id+1;

        DB::table('student')->insert([
            'student_id' => "S-".str_pad($id, 4, '0', STR_PAD_LEFT),
            'student_name' => 'Rizki Aryandi',
            'student_class' => 'RPL-1',
            'student_gender' => 'MALE',
            'student_address' => 'Sindang Palay'
        ]);


        $faker = Faker::create('id_ID');
 
    	for($i = 1; $i <= 20; $i++){
            
            $jml_id=DB::table('student')->count();
            $id=$jml_id+1;

    		DB::table('student')->insert([
                'student_id' => "S-".str_pad($id, 4, '0', STR_PAD_LEFT),
                'student_name' => $faker->name,
                'student_class' => $faker->randomElement(['RPL-1','RPL-2','RPL-3']),
                'student_gender' => $faker->randomElement(['MALE','FEMALE']),
                'student_address' => $this->cek_str($faker->address)
                
    		]);
 
    	}
    }

    public function cek_str($val)
    {
        if (strpos($val, 'Bandung')) {
            return str_replace("Bandung","Bali",$val);
        }
        else{
            return $val;
        }
    }
}
