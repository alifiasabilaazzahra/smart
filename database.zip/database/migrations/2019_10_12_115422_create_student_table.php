<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateStudentTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('student', function (Blueprint $table) {
            $table->string('student_id',6)->primary();
            $table->string('student_name',50)->nullable();
            $table->enum('student_class',['RPL-1','RPL-2','RPL-3'])->nullable();
            $table->enum('student_gender',['MALE','FEMALE'])->nullable();
            $table->text('student_address')->nullable();
            $table->tinyInteger('student_status')->default('1');
            $table->timestamps();

// student _name VARCHAR (50), NOT NULL
// o student _class ENUM (‘RPL-1’,’RPL-2’,’RPL-3’), NULLABLE
// o student _gender ENUM (‘MALE’,’FEMALE’), NULLABLE
// o student_address TEXT, NULLABLE
// o student_status TINYINTEGER, DEFAULT 1
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('student');
    }
}
